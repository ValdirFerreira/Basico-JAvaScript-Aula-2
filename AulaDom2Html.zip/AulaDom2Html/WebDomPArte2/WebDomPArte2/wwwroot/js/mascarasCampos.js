﻿function Enum(e) {
    var tecla = (window.event) ? event.keyCode : e.which;
    if ((tecla > 47 && tecla < 58)) return true;
    else {
        if (tecla == 8 || tecla == 0) return true;
        else return false;
    }
}
function MascaraCPF(campo, teclaPress) {
    if (window.event) {
        var tecla = teclaPress.KeyCode;
    }
    else {
        tecla = teclaPress.which;
    }
    var s = new String(campo.value);
    tam = s.length + 1;

    if (tam == 4) {
        campo.value = s.substr(0, 4) + ".";
    }
    if (tam == 8) {
        campo.value = s.substr(0, 8) + ".";
    }
    if (tam == 12) {
        campo.value = s.substr(0, 12) + "-";
    }

}
function MascaraTelefone(campo, teclaPress) {
    if (window.event) {
        var tecla = teclaPress.KeyCode;
    }
    else {
        tecla = teclaPress.which;
    }

    var s = new String(campo.value);
    tam = s.length + 1;

    if (tam == 2) {
        campo.value = "(" + s.substr(0, 2);
    }

    if (tam == 4) {
        campo.value = s.substr(0, 4) + ")";
    }

    if (tam == 9) {
        campo.value = s.substr(0, 9) + "-";
    }

}
function ChangeColorFocus(obj, evt) {
    if (evt.type == "focus") {
        obj.style.background = "red";
    }
    else if (evt.type == "blur") {
        obj.style.background = "white";
    }
}
